const express = require('express');
const router = express.Router();
const product_imageController = require('../controller/product_imageController');
const { authenticateAdminToken, authenticateBothTokens, authenticateUserToken } = require('../config/auth');

router.get('/', authenticateAdminToken, product_imageController.getAllProductImage);


module.exports = router;

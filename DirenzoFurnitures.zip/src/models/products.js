const { DataTypes } = require('sequelize');
const sequelize = require('../config/sequelize');
const Account = require('./account');

const Product = sequelize.define('product', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false,
    },
    accountid: {
        type: DataTypes.INTEGER,
        references: {
            model: Account,
            key: 'id',
        },
        allowNull: false,
    },
    name: {
        type: DataTypes.TEXT,
        allowNull: false,
    },
    price: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    desc: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
    material: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
    dimension: {
        type: DataTypes.TEXT,
        allowNull: true,
    }
});

module.exports = Product;
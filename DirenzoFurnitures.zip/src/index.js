const sequelize = require('./config/sequelize'); // Import Sequelize config
const accountRoutes = require('./routes/accountRoutes');
const loginRoutes = require('./routes/loginRoutes');
const tokenRoutes = require('./routes/tokenRoutes');
const productsRoutes = require('./routes/productsRoutes');
const thumbnailRoutes = require('./routes/thumbnailRoutes');
const product_imageRoutes = require('./routes/product_imageRoutes');


const bodyParser = require('body-parser');
const express = require('express');
const cors = require('cors');
const path = require('path');
const app = express();

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(cors());

// // Tạo đồng bộ cơ sở dữ liệu
sequelize.sync({ force: false })
    .then(() => {
        console.log('Database & tables created!');
    })
    .catch((err) => {
        console.error('Unable to connect to the database:', err);
    });

app.use(express.static(path.join(__dirname, '../')));

// Sử dụng các route
app.use('/account', accountRoutes);
app.use('/login', loginRoutes);
app.use('/token', tokenRoutes);
app.use('/products', productsRoutes);
app.use('/thumbnail', thumbnailRoutes);
app.use('/product_image', product_imageRoutes);

app.get('/', (req, res) => {
    res.send('Hello World!');
});

// app.get('/', (req, res) => {
//     res.sendFile(path.join(__dirname, 'views', 'signup.html'));
// });



//client

app.get('/home', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'client', 'home.html'));
});

app.get('/about-us', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'client', 'about-us.html'));
});
app.get('/product-item?product=Sofa', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'client', 'product-item.html'));
});
app.get('/product-item?product=Coffee Table', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'client', 'product-item.html'));
});
app.get('/product-item?product=Nightstand', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'client', 'product-item.html'));
});
app.get('/product-item?product=Bed', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'client', 'product-item.html'));
});
app.get('/product-item?product=Dining Chair', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'client', 'product-item.html'));
});
app.get('/product-item?product=Dining Table', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'client', 'product-item.html'));
});






//admin


app.get('/admin01628/home', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'admin', 'view-product.html'));
});
app.get('/admin01628/post', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'admin', 'add-product.html'));
});
app.get('/admin01628/put', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'admin', 'update-product.html'));
});
app.get('/admin01628/get', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'admin', 'detail-product.html'));
});







app.get('/404', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', '404.html'));
});

app.listen(5007, () => {
    console.log('Server started on port 5007');
});

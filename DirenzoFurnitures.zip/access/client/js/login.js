document.addEventListener('DOMContentLoaded', function () {
    document.getElementById('login_form').addEventListener('submit', function (event) {
        event.preventDefault(); // Ngăn chặn việc submit form mặc định
        var password = document.getElementById('Password').value;
        if (password === 'ftwg') {
            window.location.href = 'home.html';
        } else {
            alert('Mật khẩu không đúng');
        }
    });
});
